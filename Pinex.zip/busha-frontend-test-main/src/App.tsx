function App() {
  return <h1>Busha</h1>;
}

export default App;
